<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clés secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C’est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define('DB_NAME', 'lezarddrue');

/** Utilisateur de la base de données MySQL. */
define('DB_USER', 'lezarddrue');

/** Mot de passe de la base de données MySQL. */
define('DB_PASSWORD', '9lu5jxB88hqbOico+ù*8$5');

/** Adresse de l’hébergement MySQL. */
define('DB_HOST', 'localhost');

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define('DB_CHARSET', 'utf8mb4');

/** Type de collation de la base de données.
  * N’y touchez que si vous savez ce que vous faites.
  */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '`slE3OuBKol?{|Ft7nwAOKtg{:u;`@=0U~Sw`!C%PQ00cR7/C2xCvHVZ,B(hf]Du');
define('SECURE_AUTH_KEY',  ')}4,,MuWlsUrU5D`zUF?Q.1&Ry4;P>GCQ>U{6iugkXJ17; rmvrt$B&?T)]|~.6z');
define('LOGGED_IN_KEY',    'k2HSJMKZyI4N X@V5F}-xS$|o($$1lq^f&(-97~6MU)=nURRY,4[ue)>]!%er0>e');
define('NONCE_KEY',        'd4N9PL.*c]@s@eSZMem[vA8xieEQ01XisL>^%,/=f6,hN<jLW;}Vz]@!VUzL$mKg');
define('AUTH_SALT',        'Z?g-eT%_d(n~|&2aI//n+UV=h,a?kNgv{s0?BP8o&~-tE??.,[[I&YmA]A<bkWl2');
define('SECURE_AUTH_SALT', '#K(x#hytW!CR6LTJIW}/wikT T<M7*jvCm([ek;`7Vsc}Y1Q$5+Q`L)>)+_ar@9B');
define('LOGGED_IN_SALT',   '){(>t(Rc0L(FdrtHeGy?K,p3l1m`v*:#EJd^>m9)PWO-GW2.Afu^#G_cDb!3#$]>');
define('NONCE_SALT',       's!t =IH^z0~*&frV?2T{x&Eq6tfjo!(Gk)(X]@(^N8?hBB>B}oN9/pe$Ro?29RDH');
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix  = 'wp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortemment recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* C’est tout, ne touchez pas à ce qui suit ! */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');
